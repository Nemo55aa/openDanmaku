#pragma once
#pragma once

const char k[255][255] = { "aaaaaaaaa\n",
"AAA\n",

"BBBB\n",

0x5a
};

const char a[255][255] = {
	0x5a
};

